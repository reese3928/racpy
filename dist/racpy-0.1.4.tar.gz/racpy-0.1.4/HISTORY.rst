=======
History
=======

0.1.4 (2020-06-10)
------------------

* Created requirements.txt

0.1.3 (2020-04-24)
------------------

* Included extra credits in README 

0.1.2 (2020-02-18)
------------------

* Bug fixes.

0.1.0 (2020-02-09)
------------------

* Package created. First release on PyPI.
