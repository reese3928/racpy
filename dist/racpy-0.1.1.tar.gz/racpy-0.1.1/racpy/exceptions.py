

class Error(Exception):
    """Base-class for all exceptions raised by this module"""


class SetterError(Error):
    """There was a problem with the use of setter"""
