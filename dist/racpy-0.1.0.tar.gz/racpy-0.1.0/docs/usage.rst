=====
Usage
=====

To use racpy in a project::

    import racpy
