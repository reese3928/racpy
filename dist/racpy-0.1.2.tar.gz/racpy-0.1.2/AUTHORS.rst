=======
Credits
=======

Development Lead
----------------

* `Xu Ren <https://github.com/reese3928>`__ <xuren2120@gmail.com>
* `Pei Fen Kuan <http://www.ams.sunysb.edu/~pfkuan/>`__ <peifen.kuan@stonybrook.edu>


